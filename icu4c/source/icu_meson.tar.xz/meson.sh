#! /bin/sh

rm -rf builddir /opt/icu

meson setup --prefix=/opt/icu builddir

ninja -C builddir
