var searchData=
[
  ['nullorder_0',['NULLORDER',['../classicu_1_1CollationElementIterator.html#ac975b57bf50f22c7f977aba284e407e7afaf65cb7bafb29756fdaaec42cb7ab21',1,'icu::CollationElementIterator']]]
];
