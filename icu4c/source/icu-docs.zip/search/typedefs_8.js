var searchData=
[
  ['olduchar_0',['OldUChar',['../umachine_8h.html#a3ae315a8c784deae71d2078e90e5a905',1,'umachine.h']]]
];
