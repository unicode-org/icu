var searchData=
[
  ['max_5fvalue_0',['MAX_VALUE',['../classicu_1_1UnicodeSet.html#a2fe451d4023ed23a4a44d8563143492dadd725986d52c034ea1a30d1ba6f5baab',1,'icu::UnicodeSet']]],
  ['min_5fvalue_1',['MIN_VALUE',['../classicu_1_1UnicodeSet.html#a2fe451d4023ed23a4a44d8563143492da104cad219e5d184fac1b5c9e25272334',1,'icu::UnicodeSet']]]
];
