var searchData=
[
  ['unistr_0',['unistr',['../classicu_1_1StringEnumeration.html#a85fd413ec305467e295e61c7dddc1d8b',1,'icu::StringEnumeration']]],
  ['unit_1',['unit',['../structicu_1_1number_1_1impl_1_1MacroProps.html#ae62d67644319b6af92aa0269ecd13fcd',1,'icu::number::impl::MacroProps']]],
  ['unitdisplaycase_2',['unitDisplayCase',['../structicu_1_1number_1_1impl_1_1MacroProps.html#a7a0413a63ced9de02c1d1fb8d7043f69',1,'icu::number::impl::MacroProps']]],
  ['unitwidth_3',['unitWidth',['../structicu_1_1number_1_1impl_1_1MacroProps.html#a474cda1c1bd8edea73a7136b373d652a',1,'icu::number::impl::MacroProps']]],
  ['unsafeutfstringcodepoints_4',['unsafeUTFStringCodePoints',['../utfiterator_8h.html#ae761307fb6f808f749d159a0203a7316',1,'U_HEADER_ONLY_NAMESPACE']]],
  ['usage_5',['usage',['../structicu_1_1number_1_1impl_1_1MacroProps.html#a75a3c28098b16c0fb9316f60cb031daa',1,'icu::number::impl::MacroProps']]],
  ['utf8_5fcounttrailbytes_6',['utf8_countTrailBytes',['../utf__old_8h.html#ace32d87eaf64f3a7e523140f4641163b',1,'utf_old.h']]],
  ['utfstringcodepoints_7',['utfStringCodePoints',['../utfiterator_8h.html#a984a43b6a404be5a37425475b5992285',1,'U_HEADER_ONLY_NAMESPACE']]]
];
