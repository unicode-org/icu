var indexSectionsWithContent =
{
  0: "7_abcdefghijklmnopqrstuvwyz~",
  1: "abcdefgiklmnoprstuv",
  2: "i",
  3: "abcdefgilmnprstuv",
  4: "_abcdefghijklmnopqrstuvwyz~",
  5: "_abcdefghiklmnopqrstuz",
  6: "cdefgilnoprstuv",
  7: "deitu",
  8: "dfgiklmnrsuw",
  9: "cdglors",
  10: "_cdfijntu",
  11: "ls",
  12: "7adilorsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "groups",
  12: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Modules",
  12: "Pages"
};

