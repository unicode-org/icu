var searchData=
[
  ['less_0',['less',['../ucol_8h.html#a0d9895b82a8ebbae0d447c18257ef320',1,'U_HEADER_ONLY_NAMESPACE::collator']]],
  ['less_5fequal_1',['less_equal',['../ucol_8h.html#a5657975f21f9e87badb4d53df741289a',1,'U_HEADER_ONLY_NAMESPACE::collator']]]
];
