var searchData=
[
  ['iter_5fdifference_5ft_0',['iter_difference_t',['../utfiterator_8h.html#a9a573e04dceb9149b6d32dad17592008',1,'U_HEADER_ONLY_NAMESPACE::prv']]],
  ['iter_5fvalue_5ft_1',['iter_value_t',['../utfiterator_8h.html#a3ba51692c177cd5f8da05664a0319caf',1,'U_HEADER_ONLY_NAMESPACE::prv']]],
  ['iterator_5fcategory_2',['iterator_category',['../classU__HEADER__ONLY__NAMESPACE_1_1prv_1_1CodePointsIterator.html#aca3cdb7073d0401cc80bfe1e1710919e',1,'U_HEADER_ONLY_NAMESPACE::prv::CodePointsIterator::iterator_category'],['../classU__HEADER__ONLY__NAMESPACE_1_1UTFIterator.html#a9cd5aa885a385d6b7a798f939adb4806',1,'U_HEADER_ONLY_NAMESPACE::UTFIterator::iterator_category'],['../classU__HEADER__ONLY__NAMESPACE_1_1UnsafeUTFIterator.html#aaaf489fa73d950f0f5921eaebce74627',1,'U_HEADER_ONLY_NAMESPACE::UnsafeUTFIterator::iterator_category']]]
];
