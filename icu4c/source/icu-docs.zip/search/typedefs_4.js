var searchData=
[
  ['greater_0',['greater',['../ucol_8h.html#a419b15eefc21e6dbb1343d7bb4bcf298',1,'U_HEADER_ONLY_NAMESPACE::collator']]],
  ['greater_5fequal_1',['greater_equal',['../ucol_8h.html#aa312972115ad2b75d623591cb98beb37',1,'U_HEADER_ONLY_NAMESPACE::collator']]]
];
