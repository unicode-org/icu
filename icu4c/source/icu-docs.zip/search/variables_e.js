var searchData=
[
  ['offset_0',['offset',['../structUParseError.html#aa18e9bc2d82bd5a513aa489b32248f69',1,'UParseError']]],
  ['offsets_1',['offsets',['../structUConverterFromUnicodeArgs.html#a45442220ca1cd58dd6b497b2c6de0416',1,'UConverterFromUnicodeArgs::offsets'],['../structUConverterToUnicodeArgs.html#ad3b83a8bccd4642d8bc69bbf7014cfe1',1,'UConverterToUnicodeArgs::offsets']]],
  ['opts_2',['opts',['../classicu_1_1message2_1_1FunctionValue.html#a76cb194296f2bbbf4184a28edd4ba10d',1,'icu::message2::FunctionValue']]]
];
