var searchData=
[
  ['identityfallback_0',['identityFallback',['../structicu_1_1number_1_1impl_1_1RangeMacroProps.html#a16ca591be9b70c6e9621cba0cf9a33ea',1,'icu::number::impl::RangeMacroProps']]],
  ['index_1',['index',['../structUCharIterator.html#a1dcd0ca0875b1be0ba2f399c6920e6fa',1,'UCharIterator']]],
  ['innervalue_2',['innerValue',['../classicu_1_1message2_1_1FunctionValue.html#a34ee1f038dab2d84367db4090221ad36',1,'icu::message2::FunctionValue']]],
  ['inputdir_3',['inputDir',['../classicu_1_1message2_1_1FunctionValue.html#a50c1934002378aeed4dc41048cd82d77',1,'icu::message2::FunctionValue']]],
  ['integer_4',['integer',['../unionicu_1_1Transliterator_1_1Token.html#a8a28abbf5375ce471ac333cecaa03234',1,'icu::Transliterator::Token']]],
  ['integerwidth_5',['integerWidth',['../structicu_1_1number_1_1impl_1_1MacroProps.html#aabb9b8527674bf0ce67b16ebabd58582',1,'icu::number::impl::MacroProps']]],
  ['is_5fbasic_5fstring_5fview_5fv_6',['is_basic_string_view_v',['../utfiterator_8h.html#a5296d8e44f40e0d0971832c9897437cb',1,'U_HEADER_ONLY_NAMESPACE::prv']]],
  ['isbigendian_7',['isBigEndian',['../structUDataInfo.html#a91e6d8ad118435fe868a1e678b12c2d2',1,'UDataInfo']]],
  ['istransitionaldifferent_8',['isTransitionalDifferent',['../structUIDNAInfo.html#a86e3299083bda232f3692adfa1969d52',1,'UIDNAInfo']]]
];
