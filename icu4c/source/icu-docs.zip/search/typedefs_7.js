var searchData=
[
  ['not_5fequal_5fto_0',['not_equal_to',['../ucol_8h.html#abfd9825414043e41776c94b1312120ec',1,'U_HEADER_ONLY_NAMESPACE::collator']]]
];
