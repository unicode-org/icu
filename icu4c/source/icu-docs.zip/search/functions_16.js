var searchData=
[
  ['validateandget_0',['validateAndGet',['../classicu_1_1MeasureUnit.html#ab8540b50a0fca204913ebe3a33de92fa',1,'icu::MeasureUnit']]],
  ['validateargumentname_1',['validateArgumentName',['../classicu_1_1MessagePattern.html#a9b3e265c1f028bb5a0542b323d9ee776',1,'icu::MessagePattern']]],
  ['validatefield_2',['validateField',['../classicu_1_1Calendar.html#ad4f74a3879b8f67c4bbcc2e3dd4df323',1,'icu::Calendar']]],
  ['valueruns_3',['ValueRuns',['../classicu_1_1ValueRuns.html#aaf69873d9a2e8e8a6ea3fe165e7db484',1,'icu::ValueRuns::ValueRuns(const le_int32 *values, const le_int32 *limits, le_int32 count)'],['../classicu_1_1ValueRuns.html#ad4f4937b483d8368a5303ea4e20bcbe8',1,'icu::ValueRuns::ValueRuns(le_int32 initialCapacity)']]],
  ['variant_4',['Variant',['../classicu_1_1message2_1_1data__model_1_1Variant.html#a16dfe6ffb8e6b969bd4309ad3f702cf8',1,'icu::message2::data_model::Variant::Variant(const SelectorKeys &amp;keys, Pattern &amp;&amp;pattern)'],['../classicu_1_1message2_1_1data__model_1_1Variant.html#acb50246209435b517413ba00424a722f',1,'icu::message2::data_model::Variant::Variant()=default'],['../classicu_1_1message2_1_1data__model_1_1Variant.html#a07dd5871f9fd520c6625ba8ffc5741e1',1,'icu::message2::data_model::Variant::Variant(const Variant &amp;)']]],
  ['variantdisplayname_5',['variantDisplayName',['../classicu_1_1LocaleDisplayNames.html#a86089aa55d5513c796543979ea585c12',1,'icu::LocaleDisplayNames']]],
  ['visible_6',['visible',['../classicu_1_1CollatorFactory.html#a86d6d6f87c07389f733f51aae790c4b4',1,'icu::CollatorFactory::visible()'],['../classicu_1_1NumberFormatFactory.html#a3cf6e1d65c1f0f737b39dde1190d5de3',1,'icu::NumberFormatFactory::visible()'],['../classicu_1_1SimpleNumberFormatFactory.html#a27916696f0dce8d61f22616cf7034ca6',1,'icu::SimpleNumberFormatFactory::visible()']]],
  ['vtimezone_7',['VTimeZone',['../classicu_1_1VTimeZone.html#acee13a996a5ea22ea25547f1e62ee998',1,'icu::VTimeZone']]]
];
