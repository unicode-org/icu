var searchData=
[
  ['idna_0',['IDNA',['../classicu_1_1IDNA.html',1,'icu']]],
  ['idnainfo_1',['IDNAInfo',['../classicu_1_1IDNAInfo.html',1,'icu']]],
  ['immutableindex_2',['ImmutableIndex',['../classicu_1_1AlphabeticIndex_1_1ImmutableIndex.html',1,'icu::AlphabeticIndex']]],
  ['incrementprecision_3',['IncrementPrecision',['../classicu_1_1number_1_1IncrementPrecision.html',1,'icu::number']]],
  ['incrementsettings_4',['IncrementSettings',['../structicu_1_1number_1_1Precision_1_1PrecisionUnion_1_1IncrementSettings.html',1,'icu::number::Precision::PrecisionUnion']]],
  ['initialtimezonerule_5',['InitialTimeZoneRule',['../classicu_1_1InitialTimeZoneRule.html',1,'icu']]],
  ['integerwidth_6',['IntegerWidth',['../classicu_1_1number_1_1IntegerWidth.html',1,'icu::number']]],
  ['is_5fbasic_5fstring_5fview_7',['is_basic_string_view',['../structU__HEADER__ONLY__NAMESPACE_1_1prv_1_1is__basic__string__view.html',1,'U_HEADER_ONLY_NAMESPACE::prv']]],
  ['is_5fbasic_5fstring_5fview_3c_20std_3a_3abasic_5fstring_5fview_3c_20args_2e_2e_2e_20_3e_20_3e_8',['is_basic_string_view&lt; std::basic_string_view&lt; Args... &gt; &gt;',['../structU__HEADER__ONLY__NAMESPACE_1_1prv_1_1is__basic__string__view_3_01std_1_1basic__string__view_3_01Args_8_8_8_01_4_01_4.html',1,'U_HEADER_ONLY_NAMESPACE::prv']]],
  ['iterator_9',['Iterator',['../classicu_1_1BytesTrie_1_1Iterator.html',1,'icu::BytesTrie::Iterator'],['../structicu_1_1Edits_1_1Iterator.html',1,'icu::Edits::Iterator'],['../classicu_1_1Locale_1_1Iterator.html',1,'icu::Locale::Iterator'],['../structicu_1_1message2_1_1data__model_1_1Pattern_1_1Iterator.html',1,'icu::message2::data_model::Pattern::Iterator'],['../classicu_1_1UCharsTrie_1_1Iterator.html',1,'icu::UCharsTrie::Iterator']]],
  ['iterator_10',['iterator',['../structU__HEADER__ONLY__NAMESPACE_1_1CodePointRange_1_1iterator.html',1,'U_HEADER_ONLY_NAMESPACE::CodePointRange']]]
];
