var searchData=
[
  ['79_0',['ICU4C 79',['../index.html',1,'']]]
];
