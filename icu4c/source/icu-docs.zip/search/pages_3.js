var searchData=
[
  ['icu4c_2079_0',['ICU4C 79',['../index.html',1,'']]],
  ['internal_20list_1',['Internal List',['../internal.html',1,'']]]
];
